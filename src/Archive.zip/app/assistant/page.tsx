export default function Assistant() {
    return <h1>Pet Assistant</h1>;
}