export const metadata = {
  title: 'Demo | PawPal',
  description: 'Demo page for PawPawl',
};

export default function Demo() {
  return <h1>Demo</h1>;
}
